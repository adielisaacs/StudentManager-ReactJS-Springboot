package com.student.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.student.model.Student;
import com.student.respository.StudentRespository;
import com.student.service.StudentService;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
    private StudentService studentService;

    @PostMapping("/student/save")
    public ResponseEntity<Student> saveStudent(@RequestBody Student student){
    	
    	List<Student> students = studentService.findByStudentFirstnameSurname(student);
    	if(Optional.ofNullable(students.size()).orElse(0) > 0){
             return new ResponseEntity<>(HttpStatus.CONFLICT);
        }else {
         	studentService.saveStudent(student);
            return new ResponseEntity<Student>(student, HttpStatus.CREATED);
        }
    	 
    }
    
    @PutMapping("/student/update")
    public ResponseEntity<?> updateStudent(@RequestBody Student student){
    	
    	
    	Student modifiedstudent = studentService.updateStudent(student);
    	
    	if(Optional.ofNullable(modifiedstudent) != null){
    		return new ResponseEntity<>(modifiedstudent, HttpStatus.ACCEPTED);	
    	}else {
    		return new ResponseEntity<>(student, HttpStatus.NOT_MODIFIED);
    	}
        
    }
    
   
	
    @GetMapping("/student/findAllStudents")
    public ResponseEntity<?> findAllStudents(){
    	
    	List<Student> studentrecords = studentService.findAllStudents();
    	if(Optional.ofNullable(studentrecords) == null || Optional.ofNullable(studentrecords.size()).orElse(0) <= 0){
    		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    	}else {
            return new ResponseEntity<>(studentrecords, HttpStatus.OK);

    	}
    }
    
    @PostMapping("/student/getstudent")
    public ResponseEntity<?> getStudent(@RequestBody Student student){
    	
    	List<Student> students = studentService.findByStudentFirstnameSurname(student);
    	return new ResponseEntity<>(students.get(0), HttpStatus.OK);    
    }
    
    @PostMapping("/student/delete")
    public ResponseEntity<?> deleteStudent(@RequestBody Student student){
    	studentService.deleteStudent(student);
    	return new ResponseEntity<>(HttpStatus.OK);
    }
}