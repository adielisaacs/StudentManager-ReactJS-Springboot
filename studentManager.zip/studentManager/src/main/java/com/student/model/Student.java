package com.student.model;

import javax.persistence.*;

@Entity
@Table(name = "student")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "studentname")
	private String studentname;

	@Column(name = "studenttitle")
	private String studenttitle;

	@Column(name = "studentsurname")
	private String studentsurname;
	
	@Column(name = "published")
	private boolean published;
	
	public Student() {

	}

	public long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStudentname() {
		return studentname;
	}

	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}

	public String getStudenttitle() {
		return studenttitle;
	}

	public void setStudenttitle(String studenttitle) {
		this.studenttitle = studenttitle;
	}

	public String getStudentsurname() {
		return studentsurname;
	}

	public void setStudentsurname(String studentsurname) {
		this.studentsurname = studentsurname;
	}

	public boolean isPublished() {
		return published;
	}

	public void setPublished(boolean published) {
		this.published = published;
	}

	
}
