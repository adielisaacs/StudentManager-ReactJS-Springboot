package com.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.student.model.Student;
import com.student.respository.StudentRespository;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRespository studentRepository;
    
    @Autowired
    JdbcTemplate jdbcTemplate;
	
	@Override
	public Student saveStudent(Student student) {
		// TODO Auto-generated method stub
		
		studentRepository.save(student);
		return student;
	}
	
	@Override
	public Student updateStudent(Student student) {
		// TODO Auto-generated method stub
		studentRepository.save(student);

		return student;
	}
	
	
	@Override
	public void deleteStudent(Student student) {
		// TODO Auto-generated method stub
		studentRepository.delete(student);
	}

	@Override
	public List<Student> findAllStudents() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();
	}

	@Override
	public List<Student> findByStudentFirstnameSurname(Student student) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public List<Student> findByStudentFirstnameSurname(Student student) {
		// TODO Auto-generated method stub
//		List<Student> result = jdbcTemplate.query("select * from student where firstname= ? and lastname=?", new Object[] {
//				 student.getFirstName() , student.getLastName()
//		        },
//		        new BeanPropertyRowMapper <Student> (Student.class));
//		
//		
//		return result;
//	}
	
}