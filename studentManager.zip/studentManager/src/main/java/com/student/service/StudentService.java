package com.student.service;

import java.util.List;

import com.student.model.Student;

public interface StudentService {
    
	Student saveStudent(Student student);

    Student updateStudent(Student student);

    void deleteStudent(Student student);
    
    List<Student> findByStudentFirstnameSurname(Student student);
    
    List<Student> findAllStudents();

}
