package com.student.respository;

import com.student.model.Student;

import org.springframework.data.jpa.repository.JpaRepository;


public interface StudentRespository extends JpaRepository<Student, Long> {
  
}
