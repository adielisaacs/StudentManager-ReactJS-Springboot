import React, { Component } from "react";
import { Route } from "react-router-dom";
import { Link } from "react-router-dom";
import { Switch } from "react-router-dom";

import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";

import AddStudent from "./components/add-student.component";
import Student from "./components/student.component";
import StudentList from "./components/student-list.component";

class App extends Component {
  render() {
  	return (
      <div>
        <nav className="navbar navbar-expand navbar-dark bg-dark">
          <a href="/Student" className="navbar-brand">
            Student Manager
          </a>
          <div className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link to={"/Student"} className="nav-link">
                Students
              </Link>
            </li>
            <li className="nav-item">
              <Link to={"/add"} className="nav-link">
                Add
              </Link>
            </li>
          </div>
        </nav>

        <div className="container mt-3">
          <Switch>
            <Route exact path={["/", "/Student"]} component={StudentList} />
            <Route exact path="/add" component={AddStudent} />
            <Route path="/Student/:id" component={Student} />
          </Switch>
        </div>
      </div>
    );
     }
}

export default App;
