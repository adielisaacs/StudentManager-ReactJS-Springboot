import React, { Component } from "react";
import StudentDataService from "../services/Student.service";

export default class Student extends Component {
  constructor(props) {
    super(props);
    this.onChangeTitle = this.onChangeTitle.bind(this);
    this.onChangeName = this.onChangeName.bind(this);
    this.onChangeSurname = this.onChangeSurname.bind(this);
    this.getStudent = this.getStudent.bind(this);
    this.updatePublished = this.updatePublished.bind(this);
    this.updateStudent = this.updateStudent.bind(this);
    this.deleteStudent = this.deleteStudent.bind(this);

    this.state = {
      currentStudent: {
        id: null,
        studentname: "",
        studenttitle: "",
        studentsurname:"",
        published: false
      },
      message: ""
    };
  }

  componentDidMount() {
    this.getStudent(this.props.match.params.id);
  }

  onChangeTitle(e) {
    const studenttitle = e.target.value;

    this.setState(function(prevState) {
      return {
        currentStudent: {
          ...prevState.currentStudent,
          studenttitle: studenttitle
        }
      };
    });
  }

  onChangeName(e) {
    const studentname = e.target.value;
    
    this.setState(prevState => ({
      currentStudent: {
        ...prevState.currentStudent,
        studentname: studentname
      }
    }));
  }
onChangeSurname(e) {
    const studentsurname = e.target.value;
    
    this.setState(prevState => ({
      currentStudent: {
        ...prevState.currentStudent,
        studentsurname: studentsurname
      }
    }));
  }
  getStudent(id) {
    StudentDataService.get(id)
      .then(response => {
        this.setState({
          currentStudent: response.data
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  updatePublished(status) {
    var data = {
      id: this.state.currentStudent.id,
      title: this.state.currentStudent.title,
      description: this.state.currentStudent.description,
      published: status
    };

    StudentDataService.update(this.state.currentStudent.id, data)
      .then(response => {
        this.setState(prevState => ({
          currentStudent: {
            ...prevState.currentStudent,
            published: status
          }
        }));
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  updateStudent() {
    StudentDataService.update(
      this.state.currentStudent.id,
      this.state.currentStudent
    )
      .then(response => {
        console.log(response.data);
        this.setState({
          message: "The Student was updated successfully!"
        });
      })
      .catch(e => {
        console.log(e);
      });
  }

  deleteStudent() {    
    StudentDataService.delete(this.state.currentStudent.id)
      .then(response => {
        console.log(response.data);
        this.props.history.push('/Students')
      })
      .catch(e => {
        console.log(e);
      });
  }

   render() {
    const { currentStudent } = this.state;

    return (
      <div>
        {currentStudent ? (
          <div className="edit-form">
            <h4>Student</h4>
            <form>
              <div className="form-group">
                <label htmlFor="title">Title</label>
                <input
                  type="text"
                  className="form-control"
                  id="title"
                  value={currentStudent.studenttitle}
                  onChange={this.onChangeTitle}
                />
              </div>
              <div className="form-group">
                <label htmlFor="name">Name</label>
                <input
                  type="text"
                  className="form-control"
                  id="Name"
                  value={currentStudent.studentname}
                  onChange={this.onChangeName}
                />
              </div>
              <div className="form-group">
                <label htmlFor="surname">surName</label>
                <input
                  type="text"
                  className="form-control"
                  id="surName"
                  value={currentStudent.studentsurname}
                  onChange={this.onChangeSurname}
                />
              </div>  
              <div className="form-group">
                <label>
                  <strong>Status:</strong>
                </label>
                {currentStudent.published ? "Published" : "Pending"}
              </div>
            </form>

            {currentStudent.published ? (
              <button
                className="badge badge-primary mr-2"
                onClick={() => this.updatePublished(false)}
              >
                UnPublish
              </button>
            ) : (
              <button
                className="badge badge-primary mr-2"
                onClick={() => this.updatePublished(true)}
              >
                Publish
              </button>
            )}

            <button
              className="badge badge-danger mr-2"
              onClick={this.deleteStudent}
            >
              Delete
            </button>

            <button
              type="submit"
              className="badge badge-success"
              onClick={this.updateStudent}
            >
              Update
            </button>
            <p>{this.state.message}</p>
          </div>
        ) : (
          <div>
            <br />
            <p>Please click on a Student...</p>
          </div>
        )}
      </div>
    );
  }
}